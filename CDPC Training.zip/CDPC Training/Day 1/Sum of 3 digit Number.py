no = int(input("Enter a Number: "))
n1 = no%10; #4
no = no//10; 
n2 = no%10; 
no = no//10; 
n3 = no%10; 
res = n1+n2+n3
print(res)
